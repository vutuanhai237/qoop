# qtm

<img width = '200px' src = './logo.png'/>

qtm is the core module of quantum tomography and state preparation problems.

I make it an independent repository so that the tomography and state preparation repositories use the same core.
